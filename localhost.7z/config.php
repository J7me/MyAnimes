<?php
 
return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'anime_site',
        'user' => 'root',
        'pass' => '',
        'charset' => 'utf8mb4',
    ],
    // Для будущих нужд (email, secret и т.п.) возможно мне потом это понадобится...
    'app' => [
        'base_url' => '',  
    ]
];
